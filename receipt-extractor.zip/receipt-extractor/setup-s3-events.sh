#!/bin/bash
# Script to set up S3 event notifications to trigger our service

# Check if required variables are set
if [ -z "$S3_BUCKET_NAME" ] || [ -z "$EC2_INSTANCE_PUBLIC_DNS" ]; then
    echo "Please set the following variables:"
    echo "S3_BUCKET_NAME - The name of your S3 bucket"
    echo "EC2_INSTANCE_PUBLIC_DNS - The public DNS of your EC2 instance"
    echo ""
    echo "Example:"
    echo "export S3_BUCKET_NAME=ved-receipt-images-app"
    echo "export EC2_INSTANCE_PUBLIC_DNS=ec2-12-34-56-78.ap-southeast-1.compute.amazonaws.com"
    exit 1
fi

# Create SNS topic for S3 events
echo "Creating SNS topic for S3 events..."
TOPIC_ARN=$(aws sns create-topic --name ReceiptImageUploadEvents --output text --query 'TopicArn')
echo "SNS Topic ARN: $TOPIC_ARN"

# Add permission to the topic to allow S3 to publish
echo "Adding permission to SNS topic..."
aws sns add-permission \
    --topic-arn $TOPIC_ARN \
    --label s3-permission \
    --aws-account-id $(aws sts get-caller-identity --query 'Account' --output text) \
    --action-name Publish

# Create notification configuration for SNS
echo "Creating S3 event notification configuration for SNS..."
cat > notification-config-sns.json << EOL
{
    "TopicConfigurations": [
        {
            "TopicArn": "$TOPIC_ARN",
            "Events": ["s3:ObjectCreated:*"],
            "Filter": {
                "Key": {
                    "FilterRules": [
                        {
                            "Name": "prefix",
                            "Value": "receipts/"
                        },
                        {
                            "Name": "suffix",
                            "Value": ".jpg"
                        }
                    ]
                }
            }
        }
    ]
}
EOL

# Apply notification configuration
echo "Applying S3 event notification configuration..."
aws s3api put-bucket-notification-configuration \
    --bucket $S3_BUCKET_NAME \
    --notification-configuration file://notification-config-sns.json

# Create subscription to the SNS topic for our EC2 webhook
echo "Creating subscription to SNS topic for EC2 webhook..."
SUBSCRIPTION_ARN=$(aws sns subscribe \
    --topic-arn $TOPIC_ARN \
    --protocol http \
    --notification-endpoint "http://${EC2_INSTANCE_PUBLIC_DNS}:5000/process-webhook" \
    --output text --query 'SubscriptionArn')
echo "Subscription ARN: $SUBSCRIPTION_ARN"

echo ""
echo "Setup complete! Your S3 bucket '$S3_BUCKET_NAME' is now configured to send"
echo "notifications to your EC2 instance at 'http://${EC2_INSTANCE_PUBLIC_DNS}:5000/process-webhook'"
echo "whenever a new receipt image is uploaded to the 'receipts/' prefix."
echo ""
echo "Important: Make sure your EC2 security group allows inbound HTTP traffic on port 5000"

# Clean up temporary files
rm notification-config-sns.json