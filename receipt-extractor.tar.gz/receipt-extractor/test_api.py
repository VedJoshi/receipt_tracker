import requests
import base64
import sys
import json
import time

def test_health_check(base_url="http://localhost:5000"):
    """Test the health check endpoint"""
    url = f"{base_url}/health"
    
    print(f"Testing health check endpoint: {url}")
    
    try:
        response = requests.get(url)
        print(f"Status Code: {response.status_code}")
        print(json.dumps(response.json(), indent=2))
        
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_process_image(image_path, base_url="http://localhost:5000"):
    """Test the process endpoint with a local image file"""
    url = f"{base_url}/process"
    
    print(f"Testing process endpoint with image: {image_path}")
    
    try:
        # Upload the image as a file
        with open(image_path, 'rb') as f:
            files = {'file': f}
            start_time = time.time()
            response = requests.post(url, files=files)
            processing_time = time.time() - start_time
            
        print(f"Status Code: {response.status_code}")
        print(f"Processing Time: {processing_time:.2f} seconds")
        print(json.dumps(response.json(), indent=2))
        
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_process_base64(image_path, base_url="http://localhost:5000"):
    """Test the process endpoint with a base64 encoded image"""
    url = f"{base_url}/process"
    
    print(f"Testing process endpoint with base64 encoded image: {image_path}")
    
    try:
        # Read the image and encode as base64
        with open(image_path, 'rb') as f:
            image_data = f.read()
            base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # Send the base64 encoded image
        payload = {'image': base64_image}
        start_time = time.time()
        response = requests.post(url, json=payload)
        processing_time = time.time() - start_time
        
        print(f"Status Code: {response.status_code}")
        print(f"Processing Time: {processing_time:.2f} seconds")
        print(json.dumps(response.json(), indent=2))
        
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    # Get command line arguments
    if len(sys.argv) < 2:
        print("Usage: python test_api.py <image_path> [api_url]")
        sys.exit(1)
    
    image_path = sys.argv[1]
    base_url = sys.argv[2] if len(sys.argv) > 2 else "http://localhost:5000"
    
    # Run tests
    print("\n=== Testing Health Check ===")
    health_ok = test_health_check(base_url)
    
    if health_ok:
        print("\n=== Testing Process Image ===")
        test_process_image(image_path, base_url)
        
        print("\n=== Testing Process Base64 ===")
        test_process_base64(image_path, base_url)
    else:
        print("Health check failed. Make sure the API server is running.")
