#!/bin/bash

# Deploy script for EC2 instance
# This script should be run on the EC2 instance

# Exit if any command fails
set -e

echo "Starting deployment of receipt extractor service..."

# Install Docker if not already installed
if ! command -v docker &> /dev/null; then
    echo "Docker not found, installing..."
    sudo yum update -y
    sudo amazon-linux-extras install docker -y
    sudo service docker start
    sudo systemctl enable docker
    sudo usermod -a -G docker $USER
    echo "Docker installed. Please log out and log back in to apply group changes, then run this script again."
    exit 0
fi

# Install Docker Compose if not already installed
if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose not found, installing..."
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.5.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo "Docker Compose installed."
fi

# Create directory structure
mkdir -p ~/receipt-extractor/logs

# Create .env file from template if it doesn't exist
if [ ! -f ~/receipt-extractor/.env ]; then
    echo "Creating .env file from template..."
    cp .env.template ~/receipt-extractor/.env
    echo "Please edit ~/receipt-extractor/.env to set your credentials."
fi

# Copy necessary files
cp Dockerfile docker-compose.yml requirements.txt custom_model.py server.py setup-s3-events.sh ~/receipt-extractor/

# Move to the receipt-extractor directory
cd ~/receipt-extractor

# Build and start the Docker container
echo "Building and starting Docker container..."
docker-compose down || true  # Stop existing container if running
docker-compose build --no-cache  # Rebuild to ensure latest code
docker-compose up -d

# Check if the container is running
if docker ps | grep "receipt-extractor"; then
    echo "Receipt extractor service is now running!"
    echo "API is available at: http://$(curl -s http://169.254.169.254/latest/meta-data/public-hostname):5000/health"
    echo ""
    echo "To set up S3 event notifications, run:"
    echo "./setup-s3-events.sh"
else
    echo "Error: Container failed to start. Check logs with: docker-compose logs"
    exit 1
fi
