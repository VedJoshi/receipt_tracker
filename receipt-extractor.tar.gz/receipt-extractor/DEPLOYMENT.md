# Deployment Guide for Receipt Extractor

This guide explains how to deploy the custom receipt text extractor to an AWS EC2 instance and integrate it with your S3 bucket.

## Prerequisites

- An AWS account with access to EC2 and S3
- An existing S3 bucket for storing receipt images
- An EC2 instance (Amazon Linux 2 recommended)
- Basic knowledge of AWS services

## Step 1: Prepare Your Local Files

1. Ensure you have all the necessary files in your local directory:
   - `custom_model.py` - The custom text extraction model
   - `server.py` - The Flask API server
   - `requirements.txt` - Python dependencies
   - `Dockerfile` - For containerizing the application
   - `docker-compose.yml` - For running the container
   - `deploy.sh` - Deployment script
   - `setup-s3-events.sh` - Script for configuring S3 events
   - `.env.template` - Template for environment variables

2. Make sure your AWS credentials are properly secured (don't commit them to repositories).

## Step 2: Connect to Your EC2 Instance

1. If you don't already have an EC2 instance, create one:
   - Amazon Linux 2 AMI
   - t2.medium or larger (for better performance)
   - At least 20GB of storage
   - Security Group with ports 22 (SSH) and 5000 (API) open

2. Connect to your EC2 instance using SSH:
   ```bash
   ssh -i your-key.pem ec2-user@your-ec2-instance-ip
   ```

## Step 3: Transfer Files to EC2

### Option 1: Using SCP (Secure Copy)

1. Compress all required files:
   ```bash
   # From your local machine
   tar -czvf receipt-extractor.tar.gz custom_model.py server.py requirements.txt Dockerfile docker-compose.yml deploy.sh setup-s3-events.sh .env.template
   ```

2. Copy to EC2 instance:
   ```bash
   scp -i your-key.pem receipt-extractor.tar.gz ec2-user@your-ec2-instance-ip:~/
   ```

3. Extract on EC2:
   ```bash
   # On your EC2 instance
   mkdir -p receipt-extractor
   tar -xzvf receipt-extractor.tar.gz -C receipt-extractor
   cd receipt-extractor
   ```

### Option 2: Using Git (if your code is in a repository)

1. Install git on your EC2 instance:
   ```bash
   sudo yum install -y git
   ```

2. Clone your repository:
   ```bash
   git clone https://github.com/your-username/your-repo.git
   cd your-repo/receipt-extractor
   ```

## Step 4: Deploy the Application

1. Make the deployment script executable:
   ```bash
   chmod +x deploy.sh
   ```

2. Run the deployment script:
   ```bash
   ./deploy.sh
   ```

   This script will:
   - Install Docker and Docker Compose if needed
   - Copy all necessary files to the right locations
   - Create a `.env` file from the template
   - Build and start the Docker container

3. Configure your environment variables:
   ```bash
   nano ~/receipt-extractor/.env
   ```
   
   Update with your correct AWS and Supabase credentials.

4. Restart the container with updated variables:
   ```bash
   cd ~/receipt-extractor
   docker-compose down
   docker-compose up -d
   ```

## Step 5: Test the Deployment

1. Test the health check endpoint:
   ```bash
   curl http://localhost:5000/health
   ```

2. You can also test from your local machine, using the EC2's public DNS:
   ```bash
   curl http://your-ec2-public-dns:5000/health
   ```

## Step 6: Set Up S3 Event Notifications

Since S3 cannot directly call an HTTP endpoint, we need to use SNS as an intermediary:

1. Create an SNS topic:
   ```bash
   aws sns create-topic --name receipt-processing-topic
   ```
   
   Note the Topic ARN from the output.

2. Subscribe your endpoint to the SNS topic:
   ```bash
   aws sns subscribe \
     --topic-arn <TOPIC_ARN> \
     --protocol http \
     --notification-endpoint http://your-ec2-public-dns:5000/s3-webhook
   ```

3. Configure S3 to send events to the SNS topic using the AWS Console:
   - Go to S3 console: https://console.aws.amazon.com/s3/
   - Select your bucket
   - Go to 'Properties' tab
   - Under 'Event notifications', click 'Create event notification'
   - Configure:
     - Event name: receipt-upload
     - Event types: PUT, POST
     - Prefix: receipts/ (if you store receipts in this prefix)
     - Destination: SNS topic (select your topic from step 1)
   - Save changes

4. For a guided setup, you can use the provided script:
   ```bash
   # Get your EC2 public DNS
   EC2_PUBLIC_DNS=$(curl -s http://169.254.169.254/latest/meta-data/public-hostname)
   
   # Run the setup script
   ./setup-s3-events.sh $EC2_PUBLIC_DNS ved-receipt-images-app
   ```
   
   Follow the instructions provided by the script.

## Step 7: Test the Integration

1. Upload a test receipt image to your S3 bucket:
   ```bash
   aws s3 cp test_receipt.jpg s3://ved-receipt-images-app/receipts/test_receipt.jpg
   ```

2. Check the logs to confirm processing:
   ```bash
   cd ~/receipt-extractor
   docker-compose logs -f
   ```

3. Verify that a processed JSON file was created in S3:
   ```bash
   aws s3 ls s3://ved-receipt-images-app/processed/receipts/
   ```

## Troubleshooting

### Container not starting

Check the Docker logs:
```bash
cd ~/receipt-extractor
docker-compose logs
```

### S3 events not triggering processing

1. Verify SNS subscription:
   ```bash
   aws sns list-subscriptions
   ```
   
   Ensure your endpoint shows as "Confirmed".

2. Check S3 event configuration:
   ```bash
   aws s3api get-bucket-notification-configuration --bucket ved-receipt-images-app
   ```

### EC2 instance can't reach Supabase

Make sure your security group allows outbound traffic.

### Performance issues

If the model is processing slowly, consider:
- Upgrading your EC2 instance type
- Optimizing the model parameters
- Increasing the number of Gunicorn workers in the Dockerfile

## Monitoring and Maintenance

- Check logs regularly:
  ```bash
  cd ~/receipt-extractor
  docker-compose logs -f
  ```

- Update the application:
  ```bash
  # Pull new code if using git
  git pull
  # Or copy new files if using scp
  
  # Rebuild and restart
  docker-compose down
  docker-compose build --no-cache
  docker-compose up -d
  ```

- Set up CloudWatch for monitoring EC2 instance health

## Security Considerations

- Ensure your EC2 security group only allows necessary traffic
- Use IAM roles instead of AWS access keys when possible
- Keep your environment variables secure
- Regularly update your Docker images and dependencies
