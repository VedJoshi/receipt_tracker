import json
import sys
from custom_model import ReceiptTextExtractor

def test_model(image_path):
    """Test the receipt extractor model on a single image"""
    print(f"Testing model with image: {image_path}")
    
    # Initialize the model
    extractor = ReceiptTextExtractor()
    
    # Process the image
    result = extractor.process_receipt(image_path)
    
    # Print the result
    print(json.dumps(result, indent=2))
    
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test_model.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    test_model(image_path)
