#!/bin/bash

# Setup script for configuring S3 event notifications
# Make sure AWS CLI is configured with appropriate permissions

# Get the EC2 instance public DNS
EC2_PUBLIC_DNS=$1
if [ -z "$EC2_PUBLIC_DNS" ]; then
    # If not provided, try to get it automatically (only works when run on the EC2 instance)
    EC2_PUBLIC_DNS=$(curl -s http://169.254.169.254/latest/meta-data/public-hostname)
    if [ -z "$EC2_PUBLIC_DNS" ]; then
        echo "Error: EC2 public DNS not provided and could not be determined automatically."
        echo "Usage: ./setup-s3-events.sh <ec2-public-dns>"
        exit 1
    fi
fi

# Set the bucket name
S3_BUCKET_NAME=${2:-ved-receipt-images-app}

echo "Setting up S3 event notifications for bucket: $S3_BUCKET_NAME"
echo "Using EC2 public DNS: $EC2_PUBLIC_DNS"

# Webhook URL
WEBHOOK_URL="http://${EC2_PUBLIC_DNS}:5000/s3-webhook"
echo "Webhook URL: $WEBHOOK_URL"

echo "-----------------------------------"
echo "IMPORTANT INSTRUCTIONS"
echo "-----------------------------------"
echo "Since S3 can't directly call HTTP endpoints, you need to:"
echo ""
echo "1. Create an SNS topic:"
echo "   aws sns create-topic --name receipt-processing-topic"
echo ""
echo "2. Subscribe your endpoint to the SNS topic:"
echo "   aws sns subscribe --topic-arn <TOPIC_ARN> --protocol http --notification-endpoint $WEBHOOK_URL"
echo ""
echo "3. Configure S3 to send events to the SNS topic:"
echo "   - Go to S3 console: https://console.aws.amazon.com/s3/"
echo "   - Select your bucket: $S3_BUCKET_NAME"
echo "   - Go to 'Properties' tab"
echo "   - Under 'Event notifications', click 'Create event notification'"
echo "   - Configure: Event name: receipt-upload, Event types: PUT, Filter: prefix=receipts/"
echo "   - Destination: SNS topic (select your topic from step 1)"
echo "   - Save changes"
echo ""
echo "For more information, see: https://docs.aws.amazon.com/AmazonS3/latest/userguide/how-to-enable-disable-notification-intro.html"
echo "-----------------------------------"